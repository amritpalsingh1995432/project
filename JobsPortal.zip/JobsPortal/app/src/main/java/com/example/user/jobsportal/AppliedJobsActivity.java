package com.example.user.jobsportal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class AppliedJobsActivity extends AppCompatActivity {

    ListView lstAppliedJobs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_applied_jobs);

        lstAppliedJobs = findViewById(R.id.lstAppliedJobs);
        lstAppliedJobs.setAdapter(new aaplied_jobs_adapter(getApplicationContext()));

    }
}
