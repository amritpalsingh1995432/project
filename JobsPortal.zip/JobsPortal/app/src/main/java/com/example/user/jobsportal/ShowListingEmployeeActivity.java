package com.example.user.jobsportal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class ShowListingEmployeeActivity extends AppCompatActivity {

    ListView lstJobList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_show_listing_employee);

        lstJobList = findViewById(R.id.lstJobList);
        lstJobList.setAdapter(new ListJobsAdapter (getApplicationContext()));

    }

}
