package com.example.user.jobsportal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class JobApplicatiosActivity extends AppCompatActivity {

    ListView lstApplications;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_job_applicatios);

        lstApplications = findViewById(R.id.lstApplications);
        lstApplications.setAdapter(new JobApplicationsAdapter(getApplicationContext()));
    }
}
