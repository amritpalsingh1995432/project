package com.example.user.jobsportal;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ProfileActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnUpdate;
    EditText editName;
    EditText editPwd;
    Log_Information data = new Log_Information();
    String user = data.getLogged_in_user ();

    DBHelper dbHelper;
    SQLiteDatabase JobsPortalDB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_profile);

        btnUpdate = findViewById(R.id.btnUpdate);
        btnUpdate.setOnClickListener(this);

        editName = findViewById (R.id.editName);
        editPwd = findViewById (R.id.editPwd);

        dbHelper = new DBHelper(this);
        showData ();
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == btnUpdate.getId()){
            updateProfile();
            startActivity(new Intent (this,ProfileActivity.class));
        }
    }

    public void showData() {
        try {
            JobsPortalDB = dbHelper.getReadableDatabase();
            String columns[] = {"Name", "Password"};
            String userData[] = {user};

            Cursor cursor = JobsPortalDB.query("Users", columns, "Email = ?", userData, null, null, null);

            while (cursor.moveToNext()) {
                String Name = cursor.getString(cursor.getColumnIndex("Name"));
                String Password = cursor.getString(cursor.getColumnIndex("Password"));

                EditText editName = findViewById(R.id.editName);
                editName.setText(Name);

                EditText editPhone = findViewById(R.id.editPwd);
                editPhone.setText(Password);

            }
        }catch (Exception e){
            Log.e("ProfileActivity", e.getMessage());
        }finally {
            JobsPortalDB.close();
        }
    }


    public void updateProfile(){
        String name = editName.getText().toString();
        String pwd = editPwd.getText().toString();

        ContentValues cv = new  ContentValues();
        cv.put("Name",name);
        cv.put("Phone", pwd);

        try{
            JobsPortalDB = dbHelper.getWritableDatabase();
            JobsPortalDB.update("Users", cv, "Email="+user, null);
            Log.v("ProfileActivity", "Successfully Updated");

        }catch (Exception e){
            Log.e("ProfileActivity", e.getMessage());
        }finally {
            JobsPortalDB.close();
        }
    }
}
