package com.example.user.jobsportal;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class SignUpActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnSignUp;
    EditText edtName;
    EditText edtEmail;
    EditText edtPassword;
    RadioGroup rdoAccountType;
    RadioButton rdoJobseeker, rdoEmployer;
    String profile_type = "";
    DBHelper dbHelper;
    SQLiteDatabase JobsPortalDB;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        edtName=findViewById(R.id.edtName);
        edtEmail=findViewById(R.id.edtEmail);
        edtPassword=findViewById(R.id.edtPassword);

        btnSignUp=findViewById(R.id.btnSignUp);
        btnSignUp.setOnClickListener(this);

        rdoJobseeker = findViewById(R.id.rdoJobseeker);
        rdoJobseeker.setOnClickListener(this);

        rdoEmployer = findViewById(R.id.rdoEmployer);
        rdoEmployer.setOnClickListener(this);

        dbHelper = new DBHelper(this);
        db = FirebaseFirestore.getInstance();

    }

    @Override
    public void onClick(View view) {

        if(rdoEmployer.isChecked()){
            profile_type = "Employer";
        }
        else if(rdoJobseeker.isChecked()){
            profile_type = "Jobseeker";
        }

        if(view.getId() == btnSignUp.getId()){

//            String data = edtName.getText().toString()+"\n"+
//            edtEmail.getText().toString()+"\n"+edtPassword.getText().toString()+"\n"+profile_type;
//            Toast.makeText(this,data,Toast.LENGTH_LONG).show();

            if(validate ()){
                insertData();
                //displaydata();
                //Intent loginIntent=new Intent(this,LoginActivity.class);
                //startActivity(loginIntent);
            }
            else {
                Toast.makeText(this,"Enter proper details.",Toast.LENGTH_LONG).show();
            }

        }
    }

    private void insertData(){
        String name = edtName.getText().toString();
        String email = edtEmail.getText().toString();
        String password = edtPassword.getText().toString();

        Users user = new Users(name, email, password, profile_type);

        db.collection("users")
                .add(user)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Toast.makeText(getApplicationContext(), "You are registered successfully!", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(), "An error occured!", Toast.LENGTH_SHORT).show();
                    }
                })
        ;

       /* ContentValues cv = new  ContentValues();
        cv.put("Name",name);
        cv.put("Email", email);
        cv.put("Password", password);
        cv.put("Account_Type", profile_type);

        try{
            JobsPortalDB = dbHelper.getWritableDatabase();
            JobsPortalDB.insert("Users", null, cv);
            Log.v("SignUpActivity", "AccountCreated");

        }catch (Exception e){
            Log.e("SignUpActivity", e.getMessage());
        }finally {
            JobsPortalDB.close();
        } */


    }


    private void displaydata(){
       /* try{
            JobsPortalDB = dbHelper.getReadableDatabase();
            String columns[] = {"Name","Email","Password","Account_Type"};

            Cursor cursor = JobsPortalDB.query("Users", columns,null,null,null,null,null);

            while (cursor.moveToNext()){
                String UserData = cursor.getString(cursor.getColumnIndex("Name"));
                UserData += "\n" + cursor.getString(cursor.getColumnIndex("Email"));
                UserData += "\n" + cursor.getString(cursor.getColumnIndex("Password"));
                UserData += "\n" + cursor.getString(cursor.getColumnIndex("Account_Type"));

                Toast.makeText(this,UserData,Toast.LENGTH_LONG).show();
            }

        }catch (Exception e){
            Log.e("SignUpActivity",e.getMessage());
        }finally {
            JobsPortalDB.close();
        }*/
    }

    public boolean validate() {
        boolean valid = true;

        String name = edtName.getText().toString();
        String email = edtEmail.getText().toString();
        String password = edtPassword.getText().toString();

        if (name.isEmpty()) {
            edtName.setError("Enter Name");
            valid = false;
        } else {
            edtName.setError(null);
        }

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            edtEmail.setError("Enter a valid Email Address");
            valid = false;
        } else {
            edtEmail.setError(null);
        }

        if (password.isEmpty() || password.length() < 4 || password.length() > 10) {
            edtPassword.setError("Between 4 and 10 alphanumeric characters");
            valid = false;
        } else {
            edtPassword.setError(null);
        }

        if(!((rdoEmployer.isChecked ())||(rdoJobseeker.isChecked ()))){
            Toast.makeText(this, "Please Choose User Type.",
                    Toast.LENGTH_SHORT).show();
            valid = false;
        }

        return valid;
    }


}
