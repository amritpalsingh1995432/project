package com.example.user.jobsportal;

public class Users {

    String name;
    String email;
    String password;
    String profile_type;

    public Users(String name, String email, String password, String profile_type){
        this.name = name;
        this.email = email;
        this.password = password;
        this.profile_type = profile_type;
    }












}
