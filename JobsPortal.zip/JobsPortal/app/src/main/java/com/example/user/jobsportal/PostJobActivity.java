package com.example.user.jobsportal;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class PostJobActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnSubmitJob;
    EditText edtJobTitle;
    EditText edtJobDescription;
    EditText edtJobTimings;
    EditText edtJobAddress;

    Log_Information data = new Log_Information();
    String employer = data.getLogged_in_user ();

    DBHelper dbHelper;
    SQLiteDatabase JobsPortalDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_post_job);

        edtJobTitle = findViewById(R.id.edtJobTitle);
        edtJobDescription = findViewById (R.id.edtJobDescription);
        edtJobTimings = findViewById (R.id.edtJobTimings);
        edtJobAddress = findViewById (R.id.edtJobAddress);

        btnSubmitJob = findViewById (R.id.btnSubmitJob);
        btnSubmitJob.setOnClickListener (this);

        dbHelper = new DBHelper(this);

    }

    @Override
    public void onClick(View view) {
        if(view.getId() == btnSubmitJob.getId()){

            //String data = edtJobTitle.getText().toString()+"\n"+
            //edtJobDescription.getText().toString()+"\n"+edtJobTimings.getText().toString()+"\n"+edtJobAddress.getText ().toString ();
            //Toast.makeText(this,data,Toast.LENGTH_LONG).show();

            if(validate ()) {
                insertData ( );
                //displaydata ( );
                Intent homeIntent = new Intent (this, EmployerHomeActivity.class);
                startActivity (homeIntent);
            }
            else {
                Toast.makeText(this,"Enter proper details.",Toast.LENGTH_LONG).show();
            }

        }

    }

    private void insertData(){
        String job_title = edtJobTitle.getText().toString();
        String job_description = edtJobDescription.getText().toString();
        String job_type = edtJobTimings.getText().toString();
        String job_address = edtJobAddress.getText ().toString();

        ContentValues cv = new  ContentValues();
        cv.put("Job_Title",job_title);
        cv.put("Job_Description", job_description);
        cv.put("Type", job_type);
        cv.put("Address", job_address);
        cv.put ("Posted_by",employer);

        try{
            JobsPortalDB = dbHelper.getWritableDatabase();
            JobsPortalDB.insert("Jobs", null, cv);
            Log.v("PostJobActivity", "Job Posted");

        }catch (Exception e){
            Log.e("PostJobActivity", e.getMessage());
        }finally {
            JobsPortalDB.close();
        }


    }


    private void displaydata(){
        try{
            JobsPortalDB = dbHelper.getReadableDatabase();
            String columns[] = {"Job_Title","Job_Description","Type","Address","Posted_by"};

            Cursor cursor = JobsPortalDB.query("Jobs", columns,null,null,null,null,null);

            while (cursor.moveToNext()){
                String UserData = cursor.getString(cursor.getColumnIndex("Job_Title"));
                UserData += "\n" + cursor.getString(cursor.getColumnIndex("Job_Description"));
                UserData += "\n" + cursor.getString(cursor.getColumnIndex("Type"));
                UserData += "\n" + cursor.getString(cursor.getColumnIndex("Address"));
                UserData += "\n" + cursor.getString(cursor.getColumnIndex("Posted_by"));

                Toast.makeText(this,UserData,Toast.LENGTH_LONG).show();
            }

        }catch (Exception e){
            Log.e("PostJobActivity",e.getMessage());
        }finally {
            JobsPortalDB.close();
        }
    }

    public boolean validate() {
        boolean valid = true;

        String job_title = edtJobTitle.getText().toString();
        String job_description = edtJobDescription.getText().toString();
        String job_type = edtJobTimings.getText().toString();
        String job_address = edtJobAddress.getText ().toString();

        if (job_title.isEmpty()) {
            edtJobTitle.setError("Enter Job Title");
            valid = false;
        } else {
            edtJobTitle.setError(null);
        }

        if (job_description.isEmpty()) {
            edtJobDescription.setError("Enter Job Description");
            valid = false;
        } else {
            edtJobDescription.setError(null);
        }

        if (job_type.isEmpty()) {
            edtJobTimings.setError("Enter Job Type");
            valid = false;
        } else {
            edtJobTimings.setError(null);
        }

        if (job_address.isEmpty()) {
            edtJobAddress.setError("Enter Job Address");
            valid = false;
        } else {
            edtJobAddress.setError(null);
        }

        return valid;
    }
}
