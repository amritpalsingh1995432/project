package com.example.user.jobsportal;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.user.jobsportal.DBHelper;
import com.example.user.jobsportal.Log_Information;
import com.example.user.jobsportal.R;

import java.util.ArrayList;

public class aaplied_jobs_adapter extends BaseAdapter {

    LayoutInflater inflater;
    Context context;
    Log_Information data = new Log_Information();
    String employer = data.getLogged_in_user ();
    String jobseeker = data.getLogged_in_user ();
    String type = data.getUserType ();

    DBHelper dbHelper;
    SQLiteDatabase JobsPortalDB;

    ArrayList<String> jobtitle = new ArrayList<String>();
    ArrayList<String> jobdescription = new ArrayList<String>();
    ArrayList<String> jobtype = new ArrayList<String>();
    ArrayList<String> jobaddress = new ArrayList<String>();

    public aaplied_jobs_adapter(Context context){
        this.context = context;
        inflater = LayoutInflater.from(this.context);
        this.dbHelper= new DBHelper(context);

        JobsPortalDB = dbHelper.getReadableDatabase();
        String columns[] = {"Job_Title","Job_Description","Type","Address"};

        Cursor cursor = JobsPortalDB.query("Jobs_Applications", columns,null,null,null,null,null);

        while (cursor.moveToNext()){
            if (cursor.moveToFirst()) {
                do {
                    jobtitle.add(cursor.getString(cursor
                            .getColumnIndex("Job_Title")));
                    jobdescription.add(cursor.getString(cursor
                            .getColumnIndex("Job_Description")));
                    jobtype.add(cursor.getString(cursor
                            .getColumnIndex("Type")));
                    jobaddress.add(cursor.getString(cursor
                            .getColumnIndex("Address")));
                } while (cursor.moveToNext());
            }
        }
        if(!cursor.isClosed()){
            cursor.close();
        }
    }

    @Override
    public int getCount() {
        return jobtitle.size();
    }

    public void updateJobList() {

        JobsPortalDB = dbHelper.getReadableDatabase();
        String columns[] = {"Job_Title","Job_Description","Type","Address"};

        Cursor cursor = JobsPortalDB.query("Jobs_Applications", columns,null,null,null,null,null);
        jobtitle = new ArrayList<String>();
        jobdescription = new ArrayList<String>();
        jobtype = new ArrayList<String>();
        jobaddress = new ArrayList<String>();
        while (cursor.moveToNext()){
            if (cursor.moveToFirst()) {
                do {
                    jobtitle.add(cursor.getString(cursor
                            .getColumnIndex("Job_Title")));
                    jobdescription.add(cursor.getString(cursor
                            .getColumnIndex("Job_Description")));
                    jobtype.add(cursor.getString(cursor
                            .getColumnIndex("Type")));
                    jobaddress.add(cursor.getString(cursor
                            .getColumnIndex("Address")));
                } while (cursor.moveToNext());
            }
        }
        if(!cursor.isClosed()){
            cursor.close();
        }

    }


    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        view = inflater.inflate(R.layout.employer_home_job_listing, null);

        TextView txtJobTitle = view.findViewById(R.id.txtJobTitle);
        txtJobTitle.setText(jobtitle.get(position));

        TextView txtType = view.findViewById(R.id.txtType);
        txtType.setText(jobtype.get(position));

        TextView txtLocation = view.findViewById(R.id.txtLocation);
        txtLocation.setText(jobaddress.get(position));

        TextView txtDescription = view.findViewById(R.id.txtDescription);
        txtDescription.setText(jobdescription.get(position));

        return view;
    }
}
